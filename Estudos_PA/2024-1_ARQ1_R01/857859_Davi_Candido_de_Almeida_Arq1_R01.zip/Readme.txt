Fique em duvida na produção dos circuitos nas questões 1 e) e f), foi feita uma simulação no logisim levando em conta a utilização de
nand e nor com 2 entradas, no entanto devido a essa mudança a tabela verdade se alterava, devido a isso fiz a simulação com mais de 2 entradas
para que o resultado final não fosse comprometido


