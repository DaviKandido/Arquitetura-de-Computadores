Caro Professor Theldo, 

Fiquei em duvida quanto a necessidade e/ou na foma de 
desenvolvimento das tabelas sugeridas nos exercicios Oxd.)
no entanto utilizei e adaptei as tabelas contidas no arquivo
2024-2_table_templates.txt como molde para o desenvolvimento
de algumas tabelas para as resoluções dos exercicio 
(Desenvolvidas no arquivo Guia01.txt), pavor me informar 
se o desenvolvimento nesse formato esta correto,
ou se há a necessidade de desenvolve-las em arquivo .csv

Atenciosamente, Davi Cândido de Almeida, aluno de Arq 1-Tarde,
pertencente a matricula 857859