Tive um problema relacionado a saida no exercicio do guia_1305.v no verilog no qual não consegui identifica a causa do problema
por algum motivo a siada estava fixa em 1 no entanto acredito ter seguido corretamente a logica dos circuitos

Atenciosamente, Davi Cândido
